#!/usr/bin/python
# -*- coding: UTF-8 -*-

{ 'application':{ 'type':'Application',
            'name':'Minimal',

    'backgrounds':
 [ 
  { 'type':'Background',
    'name':'bgMin',
    'title':'Minimal',
    'size':( 165, 100 ),

   'components':
   [ 
    { 'type':'TextField',
      'name':'field1',
      'position':(5, 5),
      'size':(150, -1),
      'text':'Hello World!' },
   ]
  }
 ]
 }
 }

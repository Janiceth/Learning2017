#!/usr/bin/python
# -*- coding: UTF-8 -*-

import myModule
print __doc__
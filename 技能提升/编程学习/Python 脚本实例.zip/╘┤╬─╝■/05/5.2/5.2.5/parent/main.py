#!/usr/bin/python
# -*- coding: UTF-8 -*-

from pack import *
from pack2 import *

myModule.func()
myModule2.func2()
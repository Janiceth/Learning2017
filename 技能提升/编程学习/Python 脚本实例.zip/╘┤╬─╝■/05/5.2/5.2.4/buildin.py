#!/usr/bin/python
# -*- coding: UTF-8 -*-

print bool(0)

print buffer("dabcet",1,3)
print cmp(0,1)
print coerce(1,2) 
print zip((1,2),(3,4))
#!/usr/bin/python
# -*- coding: UTF-8 -*-

# �Զ���ģ��
from copy import deepcopy
count = 1

def func():
    global count
    count = count + 1
    return count

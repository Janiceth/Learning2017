#!/usr/bin/python
# -*- coding: UTF-8 -*-

# �Զ���ģ��
def func():
    print "MyModule.func()"

class MyClass:
    def myFunc(self):
        print "MyModule.MyClass.myFunc()"

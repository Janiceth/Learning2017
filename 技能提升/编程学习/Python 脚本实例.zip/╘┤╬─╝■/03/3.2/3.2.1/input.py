#!/usr/bin/python
# -*- coding: UTF-8 -*-

# raw_input()
x = raw_input("x:")
x = int(x)
x = x + 1

# input()
x = input("x:")
print x
x = raw_input("x:")
print x
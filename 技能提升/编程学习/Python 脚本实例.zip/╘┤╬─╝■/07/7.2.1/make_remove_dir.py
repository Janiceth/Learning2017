#!/usr/bin/python
# -*- coding: UTF-8 -*-

import os

os.mkdir("hello")
os.rmdir("hello")
os.makedirs("hello/world")
os.removedirs("hello/world")
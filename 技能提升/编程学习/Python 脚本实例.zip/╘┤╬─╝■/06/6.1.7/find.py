#!/usr/bin/python
# -*- coding: UTF-8 -*-

# �����ַ���
sentence = "This is a apple."
print sentence.find("a")
sentence = "This is a apple."
print sentence.rfind("a")



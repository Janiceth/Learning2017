#!/usr/bin/python
# -*- coding: UTF-8 -*-

# �ַ������滻
centence = "hello world, hello China"
print centence.replace("hello", "hi")
print centence.replace("hello", "hi", 1)
print centence.replace("abc", "hi")

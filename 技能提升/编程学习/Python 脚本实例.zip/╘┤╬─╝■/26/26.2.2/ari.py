#!/usr/bin/python
#encoding=utf-8

def add(x,y):
    print “add a, b”
    return x+y

def mul(x,y):
    print “mul a, b”
    return x*y
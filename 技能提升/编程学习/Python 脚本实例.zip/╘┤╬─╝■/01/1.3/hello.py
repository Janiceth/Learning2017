#!/usr/bin/python
# -*- coding: UTF-8 -*-

if __name__ == "__main__":
    print "hello world"
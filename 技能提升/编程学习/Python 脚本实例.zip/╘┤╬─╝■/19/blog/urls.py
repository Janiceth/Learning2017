from django.conf.urls.defaults import *

# Uncomment the next two lines to enable the admin:
from django.contrib import admin
admin.autodiscover()

urlpatterns = patterns('',
    # Example: 
    # (r'^blog/', include('blog.foo.urls')),


	# (r'^blog/', include('blog.foo.urls')),
	 (r'^$', 'blog.views.index1'),
	 (r'^login/$', 'blog.views.login'),
	 (r'^logout/$', 'blog.views.logout'),
     (r'^account/', include('blog.Account.urls')),

    # Uncomment the admin/doc line below and add 'django.contrib.admindocs' 
    # to INSTALLED_APPS to enable admin documentation:
    # (r'^admin/doc/', include('django.contrib.admindocs.urls')),

    # Uncomment the next line to enable the admin:
    (r'^admin/(.*)', admin.site.root),

)

#!/usr/bin/python
# -*- coding: UTF-8 -*-

tuple = ("apple", "banana", "grape", "orange")
#tuple[0] = "a"
t = ("apple",)
t = ()
print tuple[-1]
print tuple[-2]
#print t[0]
#!/usr/bin/python
# -*- coding: UTF-8 -*-

list = ["grape", "grape"]
list2 = ["apple", list, "orange"]             
print list
print list2

list3=[i for i in list1 if i not in list2]

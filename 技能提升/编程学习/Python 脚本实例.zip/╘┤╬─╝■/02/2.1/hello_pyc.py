import py_compile    
py_compile.compile('hello.py')
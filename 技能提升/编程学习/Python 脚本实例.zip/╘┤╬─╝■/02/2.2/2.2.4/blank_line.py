#!/usr/bin/python
# -*- coding: UTF-8 -*-

class A:
    def funX(self):
        print "funY()"

    def funY(self):
        print "funY()"

if __name__ == "__main__":
    a = A()
    a.funX()
    a.funY()


        
        
    
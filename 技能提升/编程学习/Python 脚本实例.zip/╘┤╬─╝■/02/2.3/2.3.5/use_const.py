#!/usr/bin/python
# -*- coding: UTF-8 -*-

import const
const.magic = 23  
const.magic = 33
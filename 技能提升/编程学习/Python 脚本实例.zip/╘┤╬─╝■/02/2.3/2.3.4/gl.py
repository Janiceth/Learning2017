#!/usr/bin/python
# -*- coding: UTF-8 -*-

# ȫ�ֱ���
global _a
_a = 1
_b = 2
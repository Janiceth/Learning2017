#!/usr/bin/python
# -*- coding: UTF-8 -*-

# ��Ĵ���
class Fruit:
    def grow(self):
        print "Fruit grow ..."

if __name__ == "__main__":
    fruit = Fruit()
    fruit.grow()

        
    